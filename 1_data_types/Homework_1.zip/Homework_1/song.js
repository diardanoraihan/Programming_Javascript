/* 
Title   : Homework Assignment #1: Data Types
Author  : Diardano Raihan
Task    : Create a Javascript file describing my favorite song's attributes
*/

// The name of the song takes form as a String
var song = "Time is Running Out";

// The artist of the song takes form as a String
var artist = "Muse";

// The song writers takes form as an Array
var songWriters = ["Chris Wolstenholme", "Dominic Howard", "Matthew Bellamy"];

// The album of the song takes form as a String
var album = "Absolution";

// The song nomination in the form of Boolean
var isNominated = true;

// The year of the song released takes form as a Number
var released = 2003;

// The genre of the song takes form as an Array
var genre = ["Alternative Rock", "Progressive metal"];

// The award identifi

// The sing label takes form as a String
var label = "East West";

// The song duration takes form as an Object
var duration = {inSeconds: 241, inMinutes: 4.01667};

console.log(song);
console.log(artist);
console.log(songWriters);
console.log(album);
console.log(isNominated);
console.log(released);
console.log(genre);
console.log(label);
console.log(duration);




